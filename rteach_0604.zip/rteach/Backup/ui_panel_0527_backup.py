
import bpy
from rteach.settings import IKMotionProperties, ACTIVE_ROBOT

class VIEW3D_PT_ur_ik(bpy.types.Panel):
    bl_label = "Robot Motion Simulator"
    bl_idname = "VIEW3D_PT_ur_ik"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'IK Solver'

    def draw(self, ctx):
        import math
        p = ctx.scene.ik_motion_props
        
        selected = ctx.view_layer.objects.active
        
        L = self.layout
        L.use_property_split = True
        L.use_property_decorate = False

        # ▶ Setup
        box = L.box()
        row = box.row()
        icon = 'TRIA_DOWN' if p.show_setup else 'TRIA_RIGHT'
        row.prop(p, "show_setup", icon=icon, text="Setup", emboss=False)
        if p.show_setup:
            box.prop(p, "armature", text="Armature")
            box.prop(p, "base_object", text="Robot Base")
            box.prop(p, "ee_object", text="Flange")
            box.prop(p, "tcp_object", text="TCP")

        # ▶ Target Pose
        L.separator()
        box = L.box()
        row = box.row()
        icon = 'TRIA_DOWN' if p.show_target else 'TRIA_RIGHT'
        row.prop(p, "show_target", icon=icon, text="Target Pose", emboss=False)
        if p.show_target:
            box.prop(p, "goal_object", text="Target")
            if p.goal_object:
                col = box.column(align=True)
                col.prop(p.goal_object, 'location', index=0, text="X")
                col.prop(p.goal_object, 'location', index=1, text="Y")
                col.prop(p.goal_object, 'location', index=2, text="Z")
                col.prop(p.goal_object, 'rotation_euler', index=0, text="RX")
                col.prop(p.goal_object, 'rotation_euler', index=1, text="RY")
                col.prop(p.goal_object, 'rotation_euler', index=2, text="RZ")
                box.operator("object.snap_goal_to_active", text="Snap to Selected", icon='PIVOT_ACTIVE')
            
        # ▶ Sequence Mode
        L.separator()
        box = L.box()
        row = box.row()
        icon = 'TRIA_DOWN' if p.show_teach else 'TRIA_RIGHT'
        row.prop(p, "show_teach", icon=icon, text="Sequence Mode", emboss=False)

        if p.show_teach:

            box1 = box.box()
            box1.label(text="Step 1: Teach Pose")
            box1.prop(ctx.scene, "frame_current", text="Frame")

            if p.status_text:
                if "fail" in p.status_text.lower():
                    alert_box = box1.box()
                    alert_box.alert = True
                    alert_box.label(text=f"⚠ {p.status_text.upper()} ⚠", icon='CANCEL')
                else:
                    box1.label(text=p.status_text, icon='INFO')

        # 🔧 KUKA 고정 q3 + 불러오기 버튼
        if ACTIVE_ROBOT == "KUKA":
            row = box1.row(align=True)
            row.prop(p, "fixed_q3", text="Fixed q3 (deg)")
            row.operator("object.update_fixed_q3", text="", icon='FILE_REFRESH')

            row = box1.row(align=True)
            row.operator("object.compute_ik_ur", text="Go To", icon='VIEW_CAMERA')
            row.prop(p, "auto_record", text="Record", toggle=True, icon='REC')

            pose_box = box1.box()
            pose_box.label(text=f"Pose {p.current_index + 1}/{len(p.solutions)}")
            row = pose_box.row(align=True)
            row.prop(p, "solution_index_ui", text="Pose Index")
            row.operator("object.cycle_solution_ur", text="◀").direction = 'PREV'
            row.operator("object.cycle_solution_ur", text="▶").direction = 'NEXT'
            pose_box.prop(p, "use_last_pose", text="Keep Last Pose")
            row = pose_box.row(align=True)
            row.operator("object.apply_cycle_pose", text="Apply Pose", icon='KEY_HLT')
            
            # ▶ Step 2
            box2 = box.box()
            box2.label(text="Step 2: Path & Editing")
            
            row = box2.row(align=True)
            row.operator("object.reindex_tcp_points", text="Reindex", icon='SORTALPHA')
            row.operator("object.clear_all_tcp_points", text="Clear All TCPs", icon='TRASH')
            
            row = box2.row(align=True)
            row.operator("object.draw_teach_path", text="Draw Path", icon='OUTLINER_OB_CURVE')
            row.operator("object.clear_path_visuals", text="Clear Path", icon='X')

            row = box2.row(align=True)
            row.prop(p, "selected_teach_point", text="Selected")
            row.operator("object.preview_tcp_prev", text="", icon='FRAME_PREV')
            row.operator("object.preview_tcp_next", text="", icon='FRAME_NEXT')
            
            obj = p.selected_teach_point
            if obj:
                row = box2.row(align=True)
                row.operator("object.snap_goal_to_teach_point", text="Snap", icon='RESTRICT_SELECT_OFF').name = obj.name
                row.operator("object.tcp_update_position", text="Update", icon='EXPORT').name = obj.name
                row.operator("object.tcp_delete", text="Delete", icon='X').name = obj.name

                row = box2.row(align=True)
                row.label(text="Order:")
                row.operator("object.tcp_move_up", text="↑").name = obj.name
                row.operator("object.tcp_move_down", text="↓").name = obj.name
            
            # ─────────────────────────────────────────────────────────────
            #  Step 3  –  Bake Motion  (UI draw code)
            # ─────────────────────────────────────────────────────────────
            box3 = box.box()
            box3.label(text="Step 3: Bake Motion")

            # ── Start Frame 숫자 + 키프레임 점프 버튼들 ───────────────
            row = box3.row(align=True)
            row.prop(ctx.scene, "frame_current", text="Start Frame")

            # ◀ First / ▶ Last 키프레임 jump 버튼
            row.operator("screen.frame_jump", text="", icon='REW').end = False   # ⇤ 맨 앞
            row.operator("screen.frame_jump", text="", icon='FF').end = True     # ⇥ 맨 뒤

            # ▶ 이전 / 다음 키프레임 jump 버튼
            row.operator("screen.keyframe_jump", text="", icon='PREV_KEYFRAME').next = False
            row.operator("screen.keyframe_jump", text="", icon='NEXT_KEYFRAME').next = True

            # ── Preview / Bake / Delete-Bake-Keys ───────────────────
            row = box3.row(align=True)
            row.operator("object.preview_teach_sequence", text="Preview + Play", icon='PLAY')
            row.operator("object.playback_teach_bake",     text="Bake",           icon='FILE_TICK')
            row.operator("object.clear_bake_keys",         text="",               icon='TRASH')

            obj = p.selected_teach_point

            if obj:
                box3.separator()
                box3.label(text=f"Selected: {obj.name}", icon='PINNED')

                if all(k in obj.keys() for k in ("motion_type", "frame_span", "wait_time")):
                    row = box3.row(align=True)
                    row.label(text=f"Motion Type: {obj['motion_type']}")
                    row.operator("object.toggle_motion_type", text="", icon='FILE_REFRESH')
                    box3.prop(obj, '["frame_span"]',  text="Frame Span")
                    box3.prop(obj, '["wait_time"]',   text="Wait Time")
                    box3.prop(obj, '["fixed_q3"]', text="Fixed q3 (deg)")
                else:
                    box3.label(text="< timing props missing – legacy point >", icon='ERROR')
                    












