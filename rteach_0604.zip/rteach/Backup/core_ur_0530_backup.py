# core_ur.py

from ur_analytic_ik_ext import ur16e as ur
import numpy as np

# ▶ UR 전용 본 이름과 회전축 정보
ARMATURE_BONES = ["j1", "j2", "j3", "j4", "j5", "j6"]
AXES = ['z', 'x', 'x', 'z', 'x', 'z']

def forward_kinematics(q):
    return ur.forward_kinematics(q[0], q[1], q[2], q[3], q[4], q[5])

def inverse_kinematics(T):
    return ur.inverse_kinematics(T)

def inverse_kinematics_fixed_q3(T: np.ndarray, q3: float):
    return inverse_kinematics(T)
