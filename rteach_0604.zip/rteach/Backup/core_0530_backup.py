# core.py

import math
import bpy
import numpy as np
from math import pi, degrees
from rteach.settings import ACTIVE_ROBOT
print(f"✅ [core.py] ACTIVE_ROBOT = {ACTIVE_ROBOT}")

# UR
from rteach.core_ur import (
    forward_kinematics as forward_kinematics_ur,
    inverse_kinematics as ik_ur,
    ARMATURE_BONES as UR_BONES,
    AXES as UR_AXES,
)

# KUKA
from rteach.core_iiwa import (
    forward_kinematics as forward_kinematics_iiwa,
    inverse_kinematics_fixed_q3 as ik_kuka,
    ARMATURE_BONES as IIWA_BONES,
    AXES as IIWA_AXES,
)

def get_AXES():
    from rteach.settings import ACTIVE_ROBOT
    from rteach.core_ur import AXES as UR_AXES
    from rteach.core_iiwa import AXES as IIWA_AXES
    return IIWA_AXES if ACTIVE_ROBOT == "KUKA" else UR_AXES

def get_joint_limits():
    from rteach.settings import ACTIVE_ROBOT
    if ACTIVE_ROBOT == "KUKA":
        return [(-170, 170)] * 7
    else:
        return [(-360, 360)] * 6

if ACTIVE_ROBOT == "UR":
    forward_kinematics = forward_kinematics_ur
    ARMATURE_BONES = UR_BONES
elif ACTIVE_ROBOT == "KUKA":
    forward_kinematics = forward_kinematics_iiwa
    ARMATURE_BONES = IIWA_BONES

else:
    raise ValueError(f"Unsupported robot type: {ACTIVE_ROBOT}")
    
from scipy.spatial.transform import Rotation as R

def get_forward_kinematics():
    from rteach.settings import ACTIVE_ROBOT
    from rteach.core_ur import forward_kinematics as fk_ur
    from rteach.core_iiwa import forward_kinematics as fk_kuka
    return fk_kuka if ACTIVE_ROBOT == "KUKA" else fk_ur

def get_inverse_kinematics(p):
    from rteach.settings import ACTIVE_ROBOT
    from rteach.core_iiwa import inverse_kinematics_fixed_q3
    from rteach.core_ur import inverse_kinematics

    if ACTIVE_ROBOT == "KUKA":
        return lambda T: inverse_kinematics_fixed_q3(T, p.fixed_q3)
    else:
        return inverse_kinematics

def correct_orientation_if_needed(T_goal: np.ndarray) -> np.ndarray:
    from rteach.settings import ACTIVE_ROBOT  

    if ACTIVE_ROBOT == "KUKA":
        R_corr = R.from_euler('y', -90, degrees=True).as_matrix()
        T_goal[:3, :3] = T_goal[:3, :3] @ R_corr
    return T_goal

def compute_base_matrix(p):
    return np.array(p.base_object.matrix_world) if p.base_object else np.eye(4)

def compute_tcp_offset_matrix(p):
    if p.ee_object and p.tcp_object:
        M_ee = np.array(p.ee_object.matrix_world)
        M_tcp = np.array(p.tcp_object.matrix_world)

        # 1. 기본 offset 계산 (Flange 기준에서 본 TCP)
        T_offset = np.linalg.inv(M_ee) @ M_tcp

        # 2. 사용자 보정 설정 (축 순서와 부호 조정)
        axis_order = (2, 1, 0)        
        axis_signs = (1, 1, -1)       

        # 3. 위치 벡터 보정
        pos = T_offset[:3, 3].copy()
        corrected_pos = np.zeros(3)
        for i in range(3):
            corrected_pos[i] = pos[axis_order[i]] * axis_signs[i]
        T_offset[:3, 3] = corrected_pos

        return T_offset
    return np.eye(4)

def apply_solution(arm, q, frame, insert_keyframe=True):
    from math import degrees
    AXES = get_AXES() 

    if bpy.context.scene.frame_current != frame:
        bpy.context.scene.frame_set(frame)

        for i, bn in enumerate(ARMATURE_BONES):
            pb = arm.pose.bones.get(bn)
            if pb:
                axis = AXES[i]
                angle = q[i]

            # print(f"[ApplySolution]  └─ {bn} → {round(degrees(angle), 1)} deg ({axis})")

    prev_act = bpy.context.view_layer.objects.active
    prev_mode = bpy.context.mode
    bpy.context.view_layer.objects.active = arm
    if prev_mode != 'POSE':
        bpy.ops.object.mode_set(mode='POSE')

    # print(f"\n[ApplySolution] Frame {frame}")
    # print(f"  Input q (deg): {[round(degrees(x), 1) for x in q]}")

    for i, bn in enumerate(ARMATURE_BONES):
        pb = arm.pose.bones.get(bn)
        if not pb:
            continue

        axis = AXES[i]
        pb.rotation_mode = 'XYZ'
        q_target = q[i]

        if axis == 'x':
            rot = (q_target, 0, 0)
        elif axis == 'y':
            rot = (0, q_target, 0)
        else:
            rot = (0, 0, q_target)

        pb.rotation_euler = rot
        # print(f"{bn} pose matrix: {pb.matrix}")

    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get().update()

    if insert_keyframe:
        for i, bn in enumerate(ARMATURE_BONES):
            pb = arm.pose.bones.get(bn)
            if not pb:
                continue

            axis = AXES[i]
            q_target = q[i]

            pb.keyframe_insert("rotation_euler", frame=frame)

            curve_path = f'pose.bones["{bn}"].rotation_euler'
            curve_index = {'x': 0, 'y': 1, 'z': 2}[axis]
            fc = arm.animation_data.action.fcurves.find(curve_path, index=curve_index)
            if fc:
                to_delete = [kp for kp in fc.keyframe_points if int(kp.co[0]) == frame]
                for kp in to_delete:
                    fc.keyframe_points.remove(kp)

                fc.keyframe_points.insert(frame, q_target)
                for kp in fc.keyframe_points:
                    if int(kp.co[0]) == frame:
                        kp.interpolation = 'LINEAR'
                        # print(f"  [FCurve] ⏺ Overwritten Frame {frame} {axis.upper()} = {round(degrees(q_target),1)}°")
                fc.update()

    if prev_mode != 'POSE':
        bpy.ops.object.mode_set(mode=prev_mode)
        bpy.context.view_layer.objects.active = prev_act

def sort_solutions(sols):
    def score(q):
        s = 1 if q[0] > 0 else 0  # Shoulder
        e = 1 if q[2] > 0 else 0  # Elbow
        w = 1 if q[4] > 0 else 0  # Wrist
        return s * 4 + e * 2 + w
    return sorted(sols, key=score)

def solve_and_apply(ctx, p, T_goal, frame, insert_keyframe=True):
    from rteach.settings import ACTIVE_ROBOT
    print("[DEBUG] solve_and_apply START")
    
    T_base   = compute_base_matrix(p)
    T_offset = compute_tcp_offset_matrix(p)
    T_flange = np.linalg.inv(T_base) @ T_goal @ np.linalg.inv(T_offset)
    
    ik_solver = get_inverse_kinematics(p)
    sols = ik_solver(T_flange)
        
    print(f"[DEBUG] IK returned {len(sols)} solutions")

    if not sols:
        print("❌ IK failed")
        return False

    def ang_diff(a, b):
        return ((a - b + pi) % (2 * pi)) - pi

    # Best solution 선택
    if p.solutions and len(p.solutions) > p.current_index:
        q_prev = p.solutions[p.current_index]
        best = min(
            range(len(sols)),
            key=lambda i: sum(abs(ang_diff(sols[i][j], q_prev[j])) for j in range(len(q_prev)))
        )
    elif ACTIVE_ROBOT == "UR":
        # UR은 shoulder/elbow/wrist 설정 기반
        ss = -1 if p.shoulder == 'L' else 1
        es = -1 if p.elbow   == 'U' else 1
        ws = -1 if p.wrist   == 'I' else 1
        def score(q):
            return ((math.copysign(1, q[0]) == ss) +
                    (math.copysign(1, q[2]) == es) +
                    (math.copysign(1, q[4]) == ws))
        best = max(range(len(sols)), key=lambda i: score(sols[i]))
    else:
        # KUKA이고 이전 값도 없으면 첫 번째 해 사용
        best = 0

    # 적용
    arm = bpy.data.objects.get(p.armature)
    if not arm:
        print("[DEBUG] Armature not found:", p.armature)
        return False

    ctx.scene.frame_set(frame)

    apply_solution(arm, sols[best], frame, insert_keyframe=insert_keyframe)
    
    
    q_sel = sols[best]
    fk_func = get_forward_kinematics()
    T_fk = fk_func(q_sel)
    
    print("=== UR IK DEBUG ===")
    print("T_goal:\n", np.round(T_goal, 3))
    print(f"IK returned {len(sols)} solutions")
    ...
    print("FK of selected sol:\n", np.round(T_fk, 3))
    print("Position error:", ...)
    print("Rotation error:", ...)

    return True