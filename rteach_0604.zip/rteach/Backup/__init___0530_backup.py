bl_info = {
    "name":        "Robot Simulator for Blender",
    "author":      "Beomsoo Hwang",
    "version":     (1, 0),
    "blender":     (4, 3, 0),
    "location":    "View3D > Sidebar > IK Solver",
    "category":    "Animation"
}

import bpy
from bpy.props import EnumProperty

from rteach.settings import IKMotionProperties
from rteach.core import *

from ops_teach import *
from ui_panel import *

# Define EnumProperty immediately on import (before class registration)
if not hasattr(bpy.types.Object, "motion_enum"):
    bpy.types.Object.motion_enum = EnumProperty(
        name="Motion Type",
        items=[
            ("JOINT",  "Joint",  "Joint-space interpolation"),
            ("LINEAR", "Linear", "Linear TCP motion"),
        ],
        get=lambda self: self.get("motion_type", "JOINT"),
        set=lambda self, v: self.__setitem__("motion_type", v),
    )

classes = (
    IKMotionProperties,
    OBJECT_OT_compute_ik_ur,
    OBJECT_OT_move_l,
    OBJECT_OT_record_goal_as_empty,
    OBJECT_OT_cycle_solution_ur,
    OBJECT_OT_clear_path_visuals, 
    OBJECT_OT_apply_cycle_pose,
    OBJECT_OT_snap_goal_to_teach_point,
    OBJECT_OT_draw_teach_path,
    OBJECT_OT_playback_teach_bake,
    OBJECT_OT_playback_cycle_solution,
    OBJECT_OT_playback_apply_solution,
    OBJECT_OT_tcp_move_up,
    OBJECT_OT_tcp_move_down,
    VIEW3D_PT_ur_ik,
    OBJECT_OT_tcp_update_position,
    OBJECT_OT_tcp_delete,
    OBJECT_OT_reindex_tcp_points,
    OBJECT_OT_clear_all_tcp_points,
    OBJECT_OT_preview_tcp_next,
    OBJECT_OT_preview_tcp_prev,
    OBJECT_OT_toggle_motion_type,
    OBJECT_OT_preview_teach_sequence,
    OBJECT_OT_clear_bake_keys,
    OBJECT_OT_snap_goal_to_active,
    OBJECT_OT_update_fixed_q3_from_pose,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ik_motion_props = bpy.props.PointerProperty(type=IKMotionProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.ik_motion_props