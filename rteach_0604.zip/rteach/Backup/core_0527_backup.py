# core.py

import math
import bpy
import numpy as np
from math import pi, degrees
from rteach.settings import ACTIVE_ROBOT
print(f"✅ [core.py] ACTIVE_ROBOT = {ACTIVE_ROBOT}")

from rteach.core_ur import (
    forward_kinematics as forward_kinematics_ur, inverse_kinematics_fixed_q3,
    inverse_kinematics_fixed_q3 as ik_fixed_ur,
    ARMATURE_BONES as UR_BONES,
    AXES as UR_AXES,
)
from rteach.core_iiwa import (
    forward_kinematics as forward_kinematics_iiwa, inverse_kinematics_fixed_q3,
    inverse_kinematics_fixed_q3 as ik_fixed_iiwa,
    ARMATURE_BONES as IIWA_BONES,
    AXES as IIWA_AXES,
)

if ACTIVE_ROBOT == "UR":
    forward_kinematics = forward_kinematics_ur
    inverse_kinematics = ik_fixed_ur
    ARMATURE_BONES = UR_BONES
    AXES = UR_AXES
elif ACTIVE_ROBOT == "KUKA":
    forward_kinematics = forward_kinematics_iiwa
    inverse_kinematics = ik_fixed_iiwa
    ARMATURE_BONES = IIWA_BONES
    AXES = IIWA_AXES
else:
    raise ValueError(f"Unsupported robot type: {ACTIVE_ROBOT}")
    
from scipy.spatial.transform import Rotation as R

def correct_orientation_if_needed(T_goal: np.ndarray) -> np.ndarray:

    if ACTIVE_ROBOT == "KUKA":
        R_corr = R.from_euler('y', -90, degrees=True).as_matrix()
        T_goal[:3, :3] = T_goal[:3, :3] @ R_corr
    return T_goal


def compute_base_matrix(p):
    return np.array(p.base_object.matrix_world) if p.base_object else np.eye(4)

def compute_tcp_offset_matrix(p):
    if p.ee_object and p.tcp_object:
        M_ee = np.array(p.ee_object.matrix_world)
        M_tcp = np.array(p.tcp_object.matrix_world)

        # 1. 기본 offset 계산 (Flange 기준에서 본 TCP)
        T_offset = np.linalg.inv(M_ee) @ M_tcp

        # 2. 사용자 보정 설정 (축 순서와 부호 조정)
        # ⚠️ 순서를 바꾸고 싶을 경우 예: (2, 0, 1) → z, x, y
        axis_order = (2, 1, 0)        # 기본: x, y, z
        axis_signs = (1, 1, -1)        # 기본: 그대로 사용

        # 3. 위치 벡터 보정
        pos = T_offset[:3, 3].copy()
        corrected_pos = np.zeros(3)
        for i in range(3):
            corrected_pos[i] = pos[axis_order[i]] * axis_signs[i]
        T_offset[:3, 3] = corrected_pos

        return T_offset
    return np.eye(4)


def apply_solution(arm, q, frame, insert_keyframe=True):
    from math import degrees
    print(f"[ApplySolution] ▶ Frame {frame} → q = {[round(degrees(a), 1) for a in q]}")

    for i, bn in enumerate(ARMATURE_BONES):
        pb = arm.pose.bones.get(bn)
        if pb:
            axis = AXES[i]
            angle = q[i]
            print(f"[ApplySolution]  └─ {bn} → {round(degrees(angle), 1)} deg ({axis})")
            
    prev_act  = bpy.context.view_layer.objects.active
    prev_mode = bpy.context.mode
    bpy.context.view_layer.objects.active = arm
    if prev_mode != 'POSE':
        bpy.ops.object.mode_set(mode='POSE')

    print(f"\n[ApplySolution] Frame {frame}")
    print(f"  Input q (deg): {[round(degrees(x), 1) for x in q]}")

    for i, bn in enumerate(ARMATURE_BONES):
        pb = arm.pose.bones.get(bn)
        if not pb:
            continue

        axis = AXES[i]
        prev_rot = pb.rotation_euler.copy()
        pb.rotation_mode = 'XYZ'
        q_target = q[i]

        if axis == 'x':
            prev = prev_rot.x
            delta = ((q_target - prev + pi) % (2 * pi)) - pi
            angle = prev + delta
            rot = (angle, 0, 0)
        elif axis == 'y':
            prev = prev_rot.y
            delta = ((q_target - prev + pi) % (2 * pi)) - pi
            angle = prev + delta
            rot = (0, angle, 0)
        else:
            prev = prev_rot.z
            delta = ((q_target - prev + pi) % (2 * pi)) - pi
            angle = prev + delta
            rot = (0, 0, angle)

        pb.rotation_euler = rot

        if insert_keyframe:
            if arm.animation_data and arm.animation_data.action:
                pb.keyframe_delete("rotation_euler", frame=frame)
            pb.keyframe_insert("rotation_euler", frame=frame)

            curve_path = f'pose.bones["{bn}"].rotation_euler'
            curve_index = {'x': 0, 'y': 1, 'z': 2}[axis]
            fc = arm.animation_data.action.fcurves.find(curve_path, index=curve_index)
            if fc:
                for kp in fc.keyframe_points:
                    if int(kp.co[0]) == frame:
                        old_val = kp.co[1]
                        kp.co[1] = q_target
                        kp.interpolation = 'LINEAR'
                        print(f"  [FCurve] ✅ Key {frame} {axis.upper()} | {round(degrees(old_val),1)}° → {round(degrees(q_target),1)}°")
                fc.update()
            else:
                print(f"  [FCurve] ❌ No FCurve for {bn}.{axis.upper()}")

       # print(f"  Bone {bn:>3} | Axis: {axis.upper()} | "
       #       f"q: {round(degrees(q_target),1):>6}° → Euler: "
       #       f"{[round(degrees(x),1) for x in pb.rotation_euler]}")

    if prev_mode != 'POSE':
        bpy.ops.object.mode_set(mode=prev_mode)
        bpy.context.view_layer.objects.active = prev_act

def sort_solutions(sols):
    def score(q):
        s = 1 if q[0] > 0 else 0  # Shoulder
        e = 1 if q[2] > 0 else 0  # Elbow
        w = 1 if q[4] > 0 else 0  # Wrist
        return s * 4 + e * 2 + w
    return sorted(sols, key=score)

def get_inverse_kinematics(p):
    print("[DEBUG] inverse_kinematics_fixed_q3 in globals:", 'inverse_kinematics_fixed_q3' in globals())
    if ACTIVE_ROBOT == "KUKA":
        return lambda T: inverse_kinematics_fixed_q3(T, p.fixed_q3)
    else:
        return inverse_kinematics

def solve_and_apply(ctx, p, T_goal, frame, insert_keyframe=True):
    print("[DEBUG] solve_and_apply START")
    
    T_base   = compute_base_matrix(p)
    T_offset = compute_tcp_offset_matrix(p)
    T_flange = np.linalg.inv(T_base) @ T_goal @ np.linalg.inv(T_offset)
    

    # IK 계산
    if ACTIVE_ROBOT == "KUKA":
        sols = inverse_kinematics_fixed_q3(T_flange, p.fixed_q3)
    else:
        sols = inverse_kinematics(T_flange)
        
    print(f"[DEBUG] IK returned {len(sols)} solutions")

    if not sols:
        print("❌ IK failed")
        return False

    def ang_diff(a, b):
        return ((a - b + pi) % (2 * pi)) - pi

    # Best solution 선택
    if p.solutions and len(p.solutions) > p.current_index:
        q_prev = p.solutions[p.current_index]
        best = min(
            range(len(sols)),
            key=lambda i: sum(abs(ang_diff(sols[i][j], q_prev[j])) for j in range(len(q_prev)))
        )
    elif ACTIVE_ROBOT == "UR":
        # UR은 shoulder/elbow/wrist 설정 기반
        ss = -1 if p.shoulder == 'L' else 1
        es = -1 if p.elbow   == 'U' else 1
        ws = -1 if p.wrist   == 'I' else 1
        def score(q):
            return ((math.copysign(1, q[0]) == ss) +
                    (math.copysign(1, q[2]) == es) +
                    (math.copysign(1, q[4]) == ws))
        best = max(range(len(sols)), key=lambda i: score(sols[i]))
    else:
        # KUKA이고 이전 값도 없으면 첫 번째 해 사용
        best = 0

    # 적용
    arm = bpy.data.objects.get(p.armature)
    if not arm:
        print("[DEBUG] Armature not found:", p.armature)
        return False

    ctx.scene.frame_set(frame)

#    # 디버그 비교 코드 시작
#    T_fk = forward_kinematics(sols[best])
#    T_offset = compute_tcp_offset_matrix(p)
#    T_tcp = T_fk @ T_offset
#    T_tcp_obj = np.array(p.tcp_object.matrix_world)
#    T_flange_obj = np.array(p.ee_object.matrix_world)

#    print("\n=== [DEBUG] Goal vs FK TCP vs TCP Object ===")
#    print("🟨 T_goal (Goal Gizmo):\n", np.round(T_goal, 3))
#    print("⬛ T_flange (FK from q):\n", np.round(T_fk, 3))
#    print("🟩 T_tcp (FK * T_offset):\n", np.round(T_tcp, 3))
#    print("🟦 TCP Object matrix_world:\n", np.round(T_tcp_obj, 3))
#    print("⬜ Flange Object matrix_world (from UI):\n", np.round(T_flange_obj, 3))
#    print("📦 TCP Offset Matrix (Flange → TCP):")
#    print(np.round(T_offset, 3))
#    
#    pos_goal = T_goal[:3, 3]
#    pos_tcp = T_tcp[:3, 3]
#    pos_tcp_obj = T_tcp_obj[:3, 3]
#    pos_fk = T_fk[:3, 3]
#    pos_flange_obj = T_flange_obj[:3, 3]

#    print(f"📏 TCP vs Goal Gizmo: {np.linalg.norm(pos_tcp - pos_goal) * 1000:.2f} mm")
#    print(f"📏 TCP vs TCP Object: {np.linalg.norm(pos_tcp - pos_tcp_obj) * 1000:.2f} mm")
#    print(f"📏 TCP Object vs Goal Gizmo: {np.linalg.norm(pos_tcp_obj - pos_goal) * 1000:.2f} mm")
#    print(f"📏 FK Flange vs Flange Object: {np.linalg.norm(pos_fk - pos_flange_obj) * 1000:.2f} mm")

#    from scipy.spatial.transform import Rotation as R
#    ori_goal = R.from_matrix(T_goal[:3, :3])
#    ori_tcp = R.from_matrix(T_tcp[:3, :3])
#    ori_diff = ori_goal.inv() * ori_tcp
#    print(f"🧭 Orientation Error (Goal vs TCP): {ori_diff.magnitude() * 180/np.pi:.2f} deg")
#    # 디버그 비교 코드 끝

    apply_solution(arm, sols[best], frame, insert_keyframe=insert_keyframe)
    return True



