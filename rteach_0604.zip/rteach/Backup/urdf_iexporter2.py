import bpy
import os
import mathutils
import struct
import shutil
import xml.etree.ElementTree as ET

# -------------------------------------------------
# Scene‐level properties
# -------------------------------------------------
def init_props():
    S = bpy.types.Scene
    # Package root folder (contains urdf/ and meshes/)
    S.urdf_package_path     = bpy.props.StringProperty(
        name="Package Path", subtype='DIR_PATH', default="//"
    )
    # URDF filename (under urdf/)
    S.urdf_export_filename  = bpy.props.StringProperty(
        name="Export File", default="robot.urdf"
    )
    # Import URDF full path via file browser
    S.urdf_import_filename  = bpy.props.StringProperty(
        name="Import File", subtype='FILE_PATH'
    )
    S.urdf_export_message   = bpy.props.StringProperty(default="")
    S.urdf_import_message   = bpy.props.StringProperty(default="")

def clear_props():
    S = bpy.types.Scene
    for p in ("urdf_package_path",
              "urdf_export_filename",
              "urdf_import_filename",
              "urdf_export_message",
              "urdf_import_message"):
        if hasattr(S, p):
            delattr(S, p)

# -------------------------------------------------
# Binary STL exporter (local origin, no world transform)
# -------------------------------------------------
def write_bin_stl(obj, path, deps):
    eo   = obj.evaluated_get(deps)
    mesh = eo.to_mesh()
    mesh.calc_loop_triangles()
    with open(path, 'wb') as f:
        # 80‐byte header + triangle count
        f.write(obj.name.encode()[:80].ljust(80, b'\0'))
        f.write(struct.pack('<I', len(mesh.loop_triangles)))
        for tri in mesh.loop_triangles:
            # local coords
            v0, v1, v2 = (mesh.vertices[i].co for i in tri.vertices)
            n = (v1 - v0).cross(v2 - v0)
            if n.length:
                n.normalize()
            f.write(struct.pack('<fff', *n))
            for v in (v0, v1, v2):
                f.write(struct.pack('<fff', *v))
            f.write(struct.pack('<H', 0))
    eo.to_mesh_clear()

# -------------------------------------------------
# EXPORT URDF
# -------------------------------------------------
def export_urdf():
    sc        = bpy.context.scene
    deps      = bpy.context.evaluated_depsgraph_get()

    # 1) Determine package folders
    pkg_root  = bpy.path.abspath(sc.urdf_package_path).rstrip(os.sep)
    pkg_name  = os.path.basename(pkg_root)
    urdf_dir  = os.path.join(pkg_root, "urdf")
    meshes_dir= os.path.join(pkg_root, "meshes")
    vis_dir   = os.path.join(meshes_dir, "visual")
    col_dir   = os.path.join(meshes_dir, "collision")
    for d in (urdf_dir, vis_dir, col_dir):
        os.makedirs(d, exist_ok=True)

    # 2) Prepare URDF file path
    urdf_fp = os.path.join(urdf_dir, sc.urdf_export_filename)

    lines = [
        '<?xml version="1.0"?>',
        f'<robot name="{pkg_name}">',
        ''
    ]
    link_lookup = {}

    # 3) Export links → STL to visual/, copy to collision/, record link_lookup
    for o in bpy.context.view_layer.objects:
        if o.type != 'MESH':
            continue
        stl_name = f"{o.name}.stl"
        vis_path  = os.path.join(vis_dir,  stl_name)
        col_path  = os.path.join(col_dir,  stl_name)

        write_bin_stl(o, vis_path, deps)
        shutil.copy(vis_path, col_path)

        link_lookup[o.name] = o
        lines += [
            f'  <link name="{o.name}">',
            '    <visual>',
            '      <origin xyz="0 0 0" rpy="0 0 0"/>',
            '      <geometry>',
            f'        <mesh filename="package://{pkg_name}/meshes/visual/{stl_name}"/>',
            '      </geometry>',
            '    </visual>',
            '    <collision>',
            '      <geometry>',
            f'        <mesh filename="package://{pkg_name}/meshes/collision/{stl_name}"/>',
            '      </geometry>',
            '    </collision>',
            '    <inertial>',
            '      <origin xyz="0 0 0" rpy="0 0 0"/>',
            '      <mass value="1.0"/>',
            '      <inertia ixx="1" iyy="1" izz="1" ixy="0" ixz="0" iyz="0"/>',
            '    </inertial>',
            '  </link>', ''
        ]
    # Provide a fallback base link if needed
    link_lookup['robot_base'] = None

    # 4) Export Empty‐defined joints (using custom props)
    for e in (o for o in bpy.context.view_layer.objects if o.type == 'EMPTY'):
        if 'joint_type' not in e:
            continue
        jtype = e['joint_type']  # "prismatic" or "revolute"
        if jtype not in ('prismatic','revolute'):
            continue

        parent = e.parent.name if e.parent else 'robot_base'
        child  = next((c.name for c in e.children if c.type=='MESH'), None)
        if not child:
            continue

        pmw  = link_lookup[parent].matrix_world if link_lookup[parent] else mathutils.Matrix.Identity(4)
        lmat = pmw.inverted() @ e.matrix_world
        t, r = lmat.to_translation(), lmat.to_euler('XYZ')

        if 'axis' in e:
            axis_vec = mathutils.Vector(e['axis']).normalized()
        else:
            axis_vec = mathutils.Vector((0,1,0))

        lines += [
            f'  <joint name="{e.name}" type="{jtype}">',
            f'    <parent link="{parent}"/>',
            f'    <child  link="{child}"/>',
            f'    <origin xyz="{t.x:.4f} {t.y:.4f} {t.z:.4f}" '
             f'rpy="{r.x:.4f} {r.y:.4f} {r.z:.4f}"/>',
            f'    <axis xyz="{axis_vec.x:.4f} {axis_vec.y:.4f} {axis_vec.z:.4f}"/>'
        ]

        lower = e.get('limit_lower', None)
        upper = e.get('limit_upper', None)
        if jtype == 'prismatic':
            if lower is None: lower = 0.0
            if upper is None: upper = 0.3
        # only write <limit> if both present
        if lower is not None and upper is not None:
            lines += [
                f'    <limit lower="{lower:.4f}" upper="{upper:.4f}" '
                 'effort="1000" velocity="3.1416"/>',
                '    <dynamics damping="0" friction="0"/>'
            ]

        lines += ['  </joint>', '']

    # 5) Export bone‐based joints (Armature rest‐pose)
    arm = next((o for o in bpy.context.view_layer.objects if o.type=='ARMATURE'), None)
    if arm:
        # map bone → mesh link
        links_by_bone = {}
        for obj in bpy.context.scene.objects:
            if obj.parent_type=='BONE' and obj.parent==arm:
                links_by_bone[obj.parent_bone] = obj.name

        for bone in arm.data.bones:
            child = links_by_bone.get(bone.name)
            if not child:
                continue

            parent = (links_by_bone.get(bone.parent.name)
                      if bone.parent else 'robot_base')
            pb = arm.pose.bones[bone.name]

            # joint type: custom or fixed if no parent
            jtype = pb.get('joint_type',
                           'fixed' if bone.parent is None else 'revolute')

            pmw      = link_lookup.get(parent, None)
            pmw_mat  = pmw.matrix_world if pmw else mathutils.Matrix.Identity(4)
            rest_mat = arm.matrix_world @ bone.matrix_local
            lmat     = pmw_mat.inverted() @ rest_mat
            t, r     = lmat.to_translation(), lmat.to_euler('XYZ')

            if 'axis' in pb:
                axis_vec = mathutils.Vector(pb['axis']).normalized()
            else:
                axis_vec = mathutils.Vector((0,1,0))

            lower = pb.get('limit_lower', None)
            upper = pb.get('limit_upper', None)

            lines += [f'  <joint name="{bone.name}" type="{jtype}">']
            lines += [f'    <parent link="{parent}"/>']
            lines += [f'    <child  link="{child}"/>']
            lines += [f'    <origin xyz="{t.x:.4f} {t.y:.4f} {t.z:.4f}" '
                      f'rpy="{r.x:.4f} {r.y:.4f} {r.z:.4f}"/>']
            if jtype != 'fixed':
                lines += [f'    <axis xyz="{axis_vec.x:.4f} {axis_vec.y:.4f} {axis_vec.z:.4f}"/>']
                if lower is not None and upper is not None:
                    lines += [
                        f'    <limit lower="{lower:.4f}" upper="{upper:.4f}" '
                         'effort="1000" velocity="3.1416"/>',
                        '    <dynamics damping="0" friction="0"/>'
                    ]
            lines += ['  </joint>', '']

    lines.append('</robot>')

    # write URDF
    with open(urdf_fp, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

    sc.urdf_export_message = f"Exported to {urdf_fp}"
    print(sc.urdf_export_message)

# -------------------------------------------------
# IMPORT URDF
# -------------------------------------------------
def import_urdf():
    sc      = bpy.context.scene
    urdf_fp = bpy.path.abspath(sc.urdf_import_filename)
    if not os.path.isfile(urdf_fp):
        raise FileNotFoundError(f"URDF 파일을 찾을 수 없습니다: {urdf_fp}")

    urdf_dir = os.path.dirname(urdf_fp)
    pkg_root = os.path.dirname(urdf_dir)
    tree     = ET.parse(urdf_fp)
    robot    = tree.getroot()

    link_obj = {}

    # Links (.dae/.stl), grouped under an Empty per link
    for ln in robot.findall('link'):
        link_name = ln.get('name')
        mesh_elem = ln.find('.//mesh')

        parent_empty = bpy.data.objects.new(link_name, None)
        parent_empty.empty_display_size = 0.1
        bpy.context.collection.objects.link(parent_empty)

        if mesh_elem is not None:
            fn = mesh_elem.get('filename')
            if fn.startswith('package://'):
                idx = fn.find('/meshes/')
                rel = fn[idx+1:] if idx!=-1 else fn.split('package://',1)[1]
                fp  = os.path.join(pkg_root, rel)
            else:
                fp  = os.path.join(urdf_dir, fn)

            if os.path.isfile(fp):
                before = set(bpy.context.selected_objects)
                ext    = os.path.splitext(fp)[1].lower()
                if ext == '.stl':
                    bpy.ops.import_mesh.stl(filepath=fp)
                elif ext == '.dae':
                    bpy.ops.wm.collada_import(filepath=fp)
                after  = set(bpy.context.selected_objects)
                new_objs = after - before
                for obj in new_objs:
                    obj.parent = parent_empty
                    obj.matrix_parent_inverse = parent_empty.matrix_world.inverted()

        link_obj[link_name] = parent_empty

    # Joints
    for jt in robot.findall('joint'):
        name  = jt.get('name')
        pl   = jt.find('parent').get('link')
        cl   = jt.find('child').get('link')
        ori  = jt.find('origin')
        xyz  = [float(v) for v in ori.get('xyz').split()]
        rpy  = [float(v) for v in ori.get('rpy').split()]

        em = bpy.data.objects.new(name, None)
        em.empty_display_size = 0.1
        bpy.context.collection.objects.link(em)
        em.location, em.rotation_euler = xyz, rpy

        p_obj = link_obj.get(pl)
        if p_obj:
            em.parent = p_obj
            em.matrix_parent_inverse = p_obj.matrix_world.inverted()
        c_obj = link_obj.get(cl)
        if c_obj:
            c_obj.parent = em
            c_obj.matrix_parent_inverse = em.matrix_world.inverted()

    sc.urdf_import_message = f"Imported {os.path.basename(urdf_fp)}"
    print(sc.urdf_import_message)

# -------------------------------------------------
# Operators & Panel
# -------------------------------------------------
class URDF_OT_Export(bpy.types.Operator):
    bl_idname = "urdf.export"
    bl_label  = "Export URDF"
    def execute(self, context):
        export_urdf()
        return {'FINISHED'}

class URDF_OT_Import(bpy.types.Operator):
    bl_idname = "urdf.import"
    bl_label  = "Import URDF"
    def execute(self, context):
        import_urdf()
        return {'FINISHED'}

class URDF_PT_Panel(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'URDF'
    bl_label       = "URDF Tools"

    def draw(self, context):
        sc  = context.scene
        lay = self.layout

        lay.prop(sc, "urdf_package_path", text="Package Path")
        lay.prop(sc, "urdf_export_filename", text="Export File")
        lay.operator("urdf.export", text="Export")
        if sc.urdf_export_message:
            lay.label(text=sc.urdf_export_message)

        lay.separator()

        lay.prop(sc, "urdf_import_filename", text="Import File")
        lay.operator("urdf.import", text="Import")
        if sc.urdf_import_message:
            lay.label(text=sc.urdf_import_message)

# -------------------------------------------------
# Registration
# -------------------------------------------------
def register():
    init_props()
    for cls in (URDF_OT_Export, URDF_OT_Import, URDF_PT_Panel):
        bpy.utils.register_class(cls)

def unregister():
    for cls in (URDF_PT_Panel, URDF_OT_Import, URDF_OT_Export):
        bpy.utils.unregister_class(cls)
    clear_props()

if __name__ == "__main__":
    register()
